<?php

final class ogResort {
    public function __construct() {}
}